function calculateLoan() {
    let amount = document.getElementById("amount").value;
    let rate = document.getElementById("rate").value;
    let years = document.getElementById("years").value;

    if (amount === "" || rate === "" || years === "") {
        alert("Please enter all fields");
        return;
    }

    let principal = parseFloat(amount);
    let interestRate = parseFloat(rate) / 100 / 12;
    let totalPayments = parseFloat(years) * 12;

    let monthlyPayment = (principal * interestRate) / (1 - Math.pow(1 + interestRate, -totalPayments));

    if (isNaN(monthlyPayment)) {
        document.getElementById("monthly-payment").innerText = "$0.00";
    } else {
        document.getElementById("monthly-payment").innerText = `$${monthlyPayment.toFixed(2)}`;
    }
}
