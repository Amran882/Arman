document.addEventListener("DOMContentLoaded", () => {
    const board = document.getElementById("board");
    const statusText = document.getElementById("status");
    const resetButton = document.getElementById("reset");
    const resultScreen = document.getElementById("result-screen");
    const resultMessage = document.getElementById("result-message");
    const newGameButton = document.getElementById("new-game");
    const gameContainer = document.getElementById("game-container");

    let cells = [];
    let currentPlayer = "X";
    let gameState = ["", "", "", "", "", "", "", "", ""];
    let gameActive = true;

    const winningConditions = [
        [0, 1, 2], [3, 4, 5], [6, 7, 8], 
        [0, 3, 6], [1, 4, 7], [2, 5, 8], 
        [0, 4, 8], [2, 4, 6]
    ];

    function handleClick(index) {
        if (gameState[index] !== "" || !gameActive) return;

        gameState[index] = currentPlayer;
        cells[index].innerText = currentPlayer;

        if (checkWinner()) {
            showResult(`Player ${currentPlayer} Wins! 🎉`);
            return;
        }

        if (!gameState.includes("")) {
            showResult("It's a Draw! 😐");
            return;
        }

        currentPlayer = currentPlayer === "X" ? "O" : "X";
        statusText.innerText = `Player ${currentPlayer}'s Turn`;
    }

    function checkWinner() {
        return winningConditions.some(condition => {
            const [a, b, c] = condition;
            return gameState[a] && gameState[a] === gameState[b] && gameState[a] === gameState[c];
        });
    }

    function showResult(message) {
        gameActive = false;
        resultMessage.innerText = message;
        resultScreen.style.display = "block";
        gameContainer.style.display = "none";
    }

    function resetGame() {
        gameState = ["", "", "", "", "", "", "", "", ""];
        gameActive = true;
        currentPlayer = "X";
        statusText.innerText = `Player X's Turn`;
        cells.forEach(cell => cell.innerText = "");
    }

    function startNewGame() {
        resetGame();
        resultScreen.style.display = "none";
        gameContainer.style.display = "flex";
    }

    function initializeBoard() {
        for (let i = 0; i < 9; i++) {
            const cell = document.createElement("div");
            cell.classList.add("cell");
            cell.addEventListener("click", () => handleClick(i));
            board.appendChild(cell);
            cells.push(cell);
        }
        statusText.innerText = `Player X's Turn`;
    }

    resetButton.addEventListener("click", resetGame);
    newGameButton.addEventListener("click", startNewGame);
    initializeBoard();
});
